from distutils.core import setup

setup(
    name        = 'nester_cocvu9x',
    version     = '1.4.0',
    py_modules  = ['nester'],
    author      = 'cocvu9x',
    author_email= 'cocvu99@gmail.com',
    url         = 'https://github.com/cocvu99',
    description = 'Phien ban don gian nhat nested lists cua vu nguyen',
)